#include <gl-ii-CAN.h>
#include <math.h>
using namespace glii;

// Board must already be configured for MIT mode (control mode 0).
// These examples do not change its saved mode or encoding ranges.
constexpr float kVelocityAmplitude = 0.5f; // Board velocity units; confirm rad/s vs rev/s.
constexpr float kFrequencyHz = 0.2f;       // One forward/reverse cycle every 5 seconds.
constexpr float kVelocityGain = 0.02f;    // MIT kd.

constexpr uint32_t kCommandPeriodMs = 10; // 100 Hz
constexpr uint32_t kFeedbackTimeoutMs = 250;
constexpr uint32_t kEnableTimeoutMs = 1000;
constexpr float kRampSeconds = 1.0f;

Config makeConfig() {
  Config c;
  c.txPin = GPIO_NUM_17; // CoreS3; Tab5 routing may require GPIO 6/7.
  c.rxPin = GPIO_NUM_18;
  c.bitrate = 1000000;
  c.motorId = 1;
  c.feedbackId = 0; // Confirmed standard reply ID for this board.
  c.feedbackExtended = false;
  c.positionRange = 12.5f;
  c.velocityRange = 30.0f; // MUST match motor configuration; not automatically detected.
  c.torqueRange = 10.0f;
  return c;
}
GLIICAN motor(makeConfig());
struct UserData {
  MotorFeedback feedback;
  uint32_t receivedAtMs = 0;
  bool received = false;
};
UserData motorData;
enum class State { Stopped, Enabling, Running };
State state = State::Stopped;
uint32_t enableAtMs = 0, runAtMs = 0, lastCommandMs = 0;
bool stopPending = false;
uint32_t stopAtMs = 0;
float requestedVelocity = 0.0f, requestedTorque = 0.0f;

void onFeedback(const MotorFeedback& feedback, void* context) {
  auto* data = static_cast<UserData*>(context);
  data->feedback = feedback;
  data->receivedAtMs = millis();
  data->received = true;
}
void stopMotor(const char* reason) {
  state = State::Stopped;
  requestedVelocity = requestedTorque = 0.0f;
  motor.mit(0, 0, 0, 0, 0);
  motor.special(0xFD);
  // Retry briefly if an earlier disable was lost/queue-full. A broken CAN link
  // cannot guarantee a stop; configure the board's own communication watchdog.
  stopPending = true;
  stopAtMs = millis();
  Serial.println(reason);
}
void handleConsole() {
  while (Serial.available()) {
    char command = Serial.read();
    if (command == 'x') stopMotor("Stop requested");
    if (command == 'e' && state == State::Stopped) {
      stopPending = false;
      // Discard software feedback from before this explicit enable request.
      motorData.received = false;
      if (!motor.mit(0, 0, 0, 0, 0) || !motor.special(0xFC)) {
        stopMotor("Enable enqueue failed");
      } else {
        enableAtMs = millis(); state = State::Enabling;
        Serial.println("Enable requested; waiting for fresh enabled feedback...");
      }
    }
  }
}
void setup() {
  Serial.begin(115200);
  for (int i = 0; i < 30 && !Serial; ++i) delay(100);
  motor.onFeedback(onFeedback, &motorData);
  if (!motor.begin()) {
    Serial.printf("CAN failed: %s\n", esp_err_to_name(motor.lastError()));
    while (true) delay(100);
  }
  Serial.println("SineVelocity: e=start, x=stop. Motor must be in MIT mode.");
}
void loop() {
  motor.update();
  handleConsole();
  const uint32_t now = millis();
  const bool fresh = motorData.received && uint32_t(now - motorData.receivedAtMs) <= kFeedbackTimeoutMs;
  if (state != State::Stopped && fresh && motorData.feedback.status >= 8)
    stopMotor(motorStatusName(motorData.feedback.status));
  if (state == State::Enabling) {
    if (fresh && motorData.feedback.status == 1) {
      state = State::Running; runAtMs = now;
      Serial.println("Running");
    } else if (uint32_t(now - enableAtMs) >= kEnableTimeoutMs) {
      stopMotor("Enable timed out: check reply ID, bitrate, mode and fault status");
    }
  }
  if (state == State::Running && (!fresh || motorData.feedback.status != 1))
    stopMotor("Stopped: feedback stale or motor no longer enabled");

  if (uint32_t(now - lastCommandMs) >= kCommandPeriodMs) {
    lastCommandMs = now;
    if (state == State::Enabling) {
      // Solicit feedback on boards that respond only to command packets.
      if (!motor.mit(0, 0, 0, 0, 0)) stopMotor("Feedback probe enqueue failed");
    } else if (state == State::Running) {
      const float seconds = uint32_t(now - runAtMs) * 0.001f;
      const float ramp = fminf(seconds / kRampSeconds, 1.0f);
      requestedVelocity = kVelocityAmplitude * sinf(2.0f * PI * kFrequencyHz * seconds) * ramp;
      requestedTorque = 0.0f;
      const bool queued = motor.mit(0, requestedVelocity, 0, kVelocityGain * ramp, 0);
      if (!queued) stopMotor("Command enqueue failed");
    } else if (stopPending) {
      motor.mit(0, 0, 0, 0, 0);
      motor.special(0xFD);
      if (uint32_t(now - stopAtMs) >= 1000) stopPending = false;
    }
  }
  uint32_t alerts = 0;
  if (twai_read_alerts(&alerts, 0) == ESP_OK &&
      (alerts & (TWAI_ALERT_BUS_OFF | TWAI_ALERT_TX_FAILED)) && state != State::Stopped)
    stopMotor("Stopped: CAN transmission fault");
  static uint32_t lastPrintMs = 0;
  if (uint32_t(now - lastPrintMs) >= 500) {
    lastPrintMs = now;
    if (fresh) Serial.printf("%s targetVel=%.3f targetTorque=%.3f Nm | measuredVel=%.3f torque=%.3f Nm\n",
        motorStatusName(motorData.feedback.status), requestedVelocity, requestedTorque,
        motorData.feedback.velocity, motorData.feedback.torqueNm);
    else Serial.println("No fresh motor feedback (e=start, x=stop)");
  }
  delay(1);
}
