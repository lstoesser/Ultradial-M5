#include <gl-ii-CAN.h>
using namespace glii;

Config makeConfig() {
  Config c;
  c.txPin = GPIO_NUM_17;
  c.rxPin = GPIO_NUM_18;
  c.bitrate = 1000000;
  c.motorId = 1;
  c.feedbackId = 1; // Verify using raw RX log. It may differ from motorId.
  c.positionVelocityId = 1; // Verify mode-specific IDs before using these commands.
  c.velocityId = 1;
  c.positionRange = 12.5f;
  c.velocityRange = 30.0f; // Use 200 only if that is the motor's configured range.
  c.torqueRange = 10.0f;
  return c;
}
GLIICAN motor(makeConfig());
struct MotorUserData {
  MotorFeedback lastFeedback;
  bool receivedFeedback = false;
  uint32_t lastFeedbackMs = 0;
};
MotorUserData motorUserData;
bool enabled = false;
uint32_t lastCommand = 0;

void onFeedback(const MotorFeedback& feedback, void* context) {
  auto* data = static_cast<MotorUserData*>(context);
  data->lastFeedback = feedback;
  data->receivedFeedback = true;
  data->lastFeedbackMs = millis();
}
void onRawFrame(const CanMsg& frame, void*) {
  if (motorUserData.receivedFeedback) return;
  Serial.printf("RX %s ID=%lX DLC=%u%s\n", frame.extended ? "EXT" : "STD",
                (unsigned long)frame.id, frame.length, frame.remote ? " RTR" : "");
}
void handleConsole() {
  while (Serial.available()) {
    const char command = Serial.read();
    if (command == 'e') enabled = motor.special(0xFC);
    if (command == 'x') { enabled = false; motor.special(0xFD); }
    if (command == 'z') motor.special(0xFE);
    if (command == 'c') motor.special(0xFB);
  }
}
void setup() {
  Serial.begin(115200);
  for (int i = 0; i < 30 && !Serial; ++i) delay(100);
  motor.onFeedback(onFeedback, &motorUserData);
  motor.onFrame(onRawFrame);
  if (!motor.begin()) {
    Serial.printf("CAN initialization failed: %s\n", esp_err_to_name(motor.lastError()));
    while (true) delay(100);
  }
  Serial.println("Waiting for motor feedback. e=enable, x=disable, z=zero, c=clear errors.");
  while (!motorUserData.receivedFeedback) {
    motor.update();
    handleConsole(); // Allows explicit enable if the board does not broadcast while disabled.
    delay(1);
  }
  Serial.println("Found motor");
}
void loop() {
  motor.update(); // Single receive path: do not also call twai_receive() here.
  handleConsole();
  if (enabled && uint32_t(millis() - lastCommand) >= 10) {
    lastCommand = millis();
    if (!motor.mit(0, 0, 0, 0, 0)) Serial.println("Command enqueue failed");
  }
  static uint32_t lastPrint = 0;
  if (uint32_t(millis() - lastPrint) >= 1000) {
    lastPrint = millis();
    const auto& f = motorUserData.lastFeedback;
    Serial.printf("%s pos=%.4f rad vel=%.3f torque=%.3f Nm temperatures=%d/%d C age=%lu ms\n",
                  motorStatusName(f.status), f.positionRad, f.velocity, f.torqueNm,
                  int(f.driverTemperatureC), int(f.motorTemperatureC),
                  (unsigned long)(millis() - motorUserData.lastFeedbackMs));
  }
  uint32_t alerts;
  if (twai_read_alerts(&alerts, 0) == ESP_OK) {
    if (alerts & TWAI_ALERT_BUS_OFF) { enabled = false; Serial.println("CAN bus off"); }
    if (alerts & TWAI_ALERT_TX_FAILED) Serial.println("CAN TX failed");
    if (alerts & TWAI_ALERT_RX_QUEUE_FULL) Serial.println("CAN RX queue full");
  }
  delay(1);
}
